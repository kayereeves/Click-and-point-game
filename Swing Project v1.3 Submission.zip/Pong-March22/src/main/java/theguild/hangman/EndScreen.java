
package theguild.hangman;

import java.awt.Color;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;
import static theguild.hangman.ControlWindow.*;

/**
 *
 * @author kiann
 */
public class EndScreen extends javax.swing.JFrame {
    ControlWindow controlWindow;
    int score;
    int inHST;
            
    public EndScreen() {
        this(null, 0);
    }
    
    public EndScreen(ControlWindow controlWindow, int score) {
        GlobalCode.loadJFramePreferences(this);
        this.score = score;
        
        inHST = compareScores(score); //check if score qualifies for HST
        initComponents();
        scoreText.setText(scoreText.getText() + score + " points");
        getContentPane().setBackground(GlobalCode.bgColor);
        buttonsPanel.setBackground(GlobalCode.bgColor);
        setIconImage(GlobalCode.img.getImage());
        
        this.controlWindow = controlWindow;
        
        //display button to enter high score if score qualified for HST
        if (inHST > 0 && inHST < 4)
        {
            buttonsPanel.remove(fillerPanel);
            buttonsPanel.add(scoreEntryButton);
            buttonsPanel.add(endRestartButton);
            buttonsPanel.add(endMenuButton);
        }
        
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        scoreEntryButton = new javax.swing.JButton();
        MainPanel = new javax.swing.JPanel();
        endText = new javax.swing.JLabel();
        scoreText = new javax.swing.JLabel();
        buttonsPanel = new javax.swing.JPanel();
        fillerPanel = new javax.swing.JPanel();
        endRestartButton = new javax.swing.JButton();
        endMenuButton = new javax.swing.JButton();

        scoreEntryButton.setBackground(new java.awt.Color(0, 51, 51));
        scoreEntryButton.setFont(new java.awt.Font("Showcard Gothic", 0, 10)); // NOI18N
        scoreEntryButton.setForeground(new java.awt.Color(0, 153, 153));
        scoreEntryButton.setText("Save High Score");
        scoreEntryButton.setToolTipText("Save Your Score On the High Score Log");
        scoreEntryButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                scoreEntryButtonActionPerformed(evt);
            }
        });

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new java.awt.GridBagLayout());

        MainPanel.setOpaque(false);

        endText.setBackground(new java.awt.Color(0, 51, 51));
        endText.setFont(new java.awt.Font("Showcard Gothic", 0, 24)); // NOI18N
        endText.setForeground(new java.awt.Color(0, 153, 153));
        endText.setText("You finished the game!");

        scoreText.setFont(new java.awt.Font("Showcard Gothic", 0, 18)); // NOI18N
        scoreText.setForeground(new java.awt.Color(0, 153, 153));
        scoreText.setText("You scored: ");

        buttonsPanel.setOpaque(false);
        buttonsPanel.setLayout(new java.awt.GridLayout(3, 0, 0, 10));

        fillerPanel.setOpaque(false);

        javax.swing.GroupLayout fillerPanelLayout = new javax.swing.GroupLayout(fillerPanel);
        fillerPanel.setLayout(fillerPanelLayout);
        fillerPanelLayout.setHorizontalGroup(
            fillerPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 266, Short.MAX_VALUE)
        );
        fillerPanelLayout.setVerticalGroup(
            fillerPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 40, Short.MAX_VALUE)
        );

        buttonsPanel.add(fillerPanel);

        endRestartButton.setBackground(new java.awt.Color(0, 51, 51));
        endRestartButton.setFont(new java.awt.Font("Showcard Gothic", 0, 10)); // NOI18N
        endRestartButton.setForeground(new java.awt.Color(0, 153, 153));
        endRestartButton.setText("Try Again?");
        endRestartButton.setToolTipText("Restart the game.");
        endRestartButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                endRestartButtonActionPerformed(evt);
            }
        });
        buttonsPanel.add(endRestartButton);

        endMenuButton.setBackground(new java.awt.Color(0, 51, 51));
        endMenuButton.setFont(new java.awt.Font("Showcard Gothic", 0, 10)); // NOI18N
        endMenuButton.setForeground(new java.awt.Color(0, 153, 153));
        endMenuButton.setText("Back To Menu");
        endMenuButton.setToolTipText("Go back to the main menu.");
        endMenuButton.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        endMenuButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                endMenuButtonActionPerformed(evt);
            }
        });
        buttonsPanel.add(endMenuButton);

        javax.swing.GroupLayout MainPanelLayout = new javax.swing.GroupLayout(MainPanel);
        MainPanel.setLayout(MainPanelLayout);
        MainPanelLayout.setHorizontalGroup(
            MainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(MainPanelLayout.createSequentialGroup()
                .addGroup(MainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                    .addComponent(buttonsPanel, javax.swing.GroupLayout.PREFERRED_SIZE, 266, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(endText, javax.swing.GroupLayout.PREFERRED_SIZE, 309, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(20, 20, 20))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, MainPanelLayout.createSequentialGroup()
                .addComponent(scoreText, javax.swing.GroupLayout.PREFERRED_SIZE, 272, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(37, 37, 37))
        );
        MainPanelLayout.setVerticalGroup(
            MainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(MainPanelLayout.createSequentialGroup()
                .addGap(11, 11, 11)
                .addComponent(endText, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(6, 6, 6)
                .addComponent(scoreText, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 59, Short.MAX_VALUE)
                .addComponent(buttonsPanel, javax.swing.GroupLayout.PREFERRED_SIZE, 142, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(21, 21, 21))
        );

        getContentPane().add(MainPanel, new java.awt.GridBagConstraints());

        setSize(new java.awt.Dimension(614, 437));
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void endMenuButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_endMenuButtonActionPerformed
        controlWindow.changeScreen(MENUSCREEN);
    }//GEN-LAST:event_endMenuButtonActionPerformed

    private void endRestartButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_endRestartButtonActionPerformed
        controlWindow.changeScreen(HANGMANGAME);
    }//GEN-LAST:event_endRestartButtonActionPerformed

    private void scoreEntryButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_scoreEntryButtonActionPerformed
        controlWindow.changeScreen(HSENTRY, score, inHST, 0);
    }//GEN-LAST:event_scoreEntryButtonActionPerformed

    //returns 1, 2, or 3 if user's score qualifies for the HST, or 0 if not
    private int compareScores(int score)
    {
        HighScores hst = new HighScores();
        int scorePlace = 0;
        
        for (int i = 3; i >= 1; i--) {
            int highScore = hst.getScoreIntValue(i);
            if (score > highScore) {
                scorePlace = i;
            } 
        }
        
        hst.dispose();
        return scorePlace;
    } 
    
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(EndScreen.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(EndScreen.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(EndScreen.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(EndScreen.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new ControlWindow(ENDSCREEN).setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel MainPanel;
    private javax.swing.JPanel buttonsPanel;
    private javax.swing.JButton endMenuButton;
    private javax.swing.JButton endRestartButton;
    private javax.swing.JLabel endText;
    private javax.swing.JPanel fillerPanel;
    private javax.swing.JButton scoreEntryButton;
    private javax.swing.JLabel scoreText;
    // End of variables declaration//GEN-END:variables
}

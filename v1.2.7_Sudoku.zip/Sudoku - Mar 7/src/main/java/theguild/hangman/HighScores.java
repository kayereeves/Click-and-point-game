
package theguild.hangman;

import java.awt.Color;
import java.util.Scanner;
import java.io.*;
import java.nio.file.Path;

/**
 *
 * @author kiann
 */
public class HighScores extends javax.swing.JFrame {
    
    private int numScores = 3;
    private int numScoreElems = 2;
    private String[][] hsInfo = new String[numScores][numScoreElems];

    public HighScores() {
        GlobalCode.loadJFramePreferences(this);
        initComponents();
        retrieveScores();
        getContentPane().setBackground(GlobalCode.bgColor);
        setIconImage(GlobalCode.img.getImage());
    }

    //gets the high score info from a highscoretable.txt file
    private void retrieveScores() {
        try {
            Scanner hsread = new Scanner(new File("src//main//java//resources//highscoretable.txt"));
            hsread.useDelimiter(":");
            
            for (int i = 0; i < numScores; i++) 
            {
                for (int j = 0; j < numScoreElems; j++) 
                {
                    hsInfo[i][j] = hsread.next();
                }
            }
            
            score1Text.setText(hsInfo[0][0] + "....." + hsInfo[0][1]);          
            score2Text.setText(hsInfo[1][0] + "....." + hsInfo[1][1]);
            score3Text.setText(hsInfo[2][0] + "....." + hsInfo[2][1]);
            
            hsread.close();
        }
        catch (FileNotFoundException e) {
            System.err.println("Error: invalid HST file");
        }   
    }
    
    public void setScore(int score, int position)
    {
        for (int i = numScores - 1; i >= position; i--)
        {
            hsInfo[i][1] = hsInfo[i - 1][1];
        }
        
        hsInfo[position - 1][1] = String.format("%05d", score);
    }
    
    public void setInit(String initials, int position)
    {
        for (int i = numScores - 1; i >= position; i--)
        {
            hsInfo[i][0] = hsInfo[i - 1][0];
        }
        
        hsInfo[position - 1][0] = initials;
    }
    
    public String getScore(int position)
    {
        return hsInfo[position - 1][1];
    }
    
    public String getInit(int position)
    {
        return hsInfo[position - 1][0];
    }
    
    public int getScoreIntValue(int position)
    {
        return Integer.valueOf(hsInfo[position - 1][1]);
    }  
    
    public void updateScoreFile() throws IOException
    {
        FileWriter hsWrite = new FileWriter(new File("src//main//java//resources//highscoretable.txt"));
        BufferedWriter bw = new BufferedWriter(hsWrite);
        bw.write("");
        
        for (int i = 0; i < numScores; i++) 
        {
                for (int j = 0; j < numScoreElems; j++) 
                {
                    bw.append(hsInfo[i][j] + ':');
                }
        }
        
        bw.close();
    }
    
    public void resetScoreFile() throws IOException
    {
        FileWriter hsWrite = new FileWriter(new File("src//main//java//resources//highscoretable.txt"));
        BufferedWriter bw = new BufferedWriter(hsWrite);
        
        bw.write("ABC:00000:ABC:00000:ABC:00000:");
        bw.close();
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        highScoresText = new javax.swing.JLabel();
        hsBackButton = new javax.swing.JButton();
        score1Text = new javax.swing.JLabel();
        score2Text = new javax.swing.JLabel();
        score3Text = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        highScoresText.setFont(new java.awt.Font("Showcard Gothic", 0, 36)); // NOI18N
        highScoresText.setForeground(new java.awt.Color(0, 153, 153));
        highScoresText.setText("High Scores");

        hsBackButton.setBackground(new java.awt.Color(0, 51, 51));
        hsBackButton.setFont(new java.awt.Font("Showcard Gothic", 0, 10)); // NOI18N
        hsBackButton.setForeground(new java.awt.Color(0, 153, 153));
        hsBackButton.setText("Back to menu");
        hsBackButton.setToolTipText("Go back to the main menu.");
        hsBackButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                hsBackButtonActionPerformed(evt);
            }
        });

        score1Text.setFont(new java.awt.Font("Showcard Gothic", 0, 24)); // NOI18N
        score1Text.setForeground(new java.awt.Color(0, 153, 153));
        score1Text.setText("ABC.....00000");

        score2Text.setFont(new java.awt.Font("Showcard Gothic", 0, 24)); // NOI18N
        score2Text.setForeground(new java.awt.Color(0, 153, 153));
        score2Text.setText("ABC.....00000");

        score3Text.setFont(new java.awt.Font("Showcard Gothic", 0, 24)); // NOI18N
        score3Text.setForeground(new java.awt.Color(0, 153, 153));
        score3Text.setText("ABC.....00000");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(173, 173, 173)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(highScoresText, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(score2Text, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(score1Text, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(score3Text, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(hsBackButton, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(197, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(63, 63, 63)
                .addComponent(highScoresText)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(score1Text, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(score2Text)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(score3Text)
                .addGap(18, 18, 18)
                .addComponent(hsBackButton, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(121, Short.MAX_VALUE))
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void hsBackButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_hsBackButtonActionPerformed
        MenuScreen menu = new MenuScreen();
        menu.setSize(600,400);
        menu.setVisible(true);
        this.setVisible(false);
        this.setDefaultCloseOperation(this.EXIT_ON_CLOSE);
        this.dispose();
    }//GEN-LAST:event_hsBackButtonActionPerformed

    private void hsMainMenuButtonActionPerformed(java.awt.event.ActionEvent evt) {                                         
        MenuScreen menu = new MenuScreen();
        menu.setSize(600,400);
        menu.setVisible(true);
        this.setVisible(false);
        this.setDefaultCloseOperation(this.EXIT_ON_CLOSE);
        this.dispose();
    }  
    
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(HighScores.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(HighScores.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(HighScores.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(HighScores.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new HighScores().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel highScoresText;
    private javax.swing.JButton hsBackButton;
    private javax.swing.JLabel score1Text;
    private javax.swing.JLabel score2Text;
    private javax.swing.JLabel score3Text;
    // End of variables declaration//GEN-END:variables
}

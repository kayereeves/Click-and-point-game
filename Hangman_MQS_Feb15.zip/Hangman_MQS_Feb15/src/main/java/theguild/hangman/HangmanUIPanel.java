
package theguild.hangman;

import javax.swing.SwingUtilities;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.BorderFactory;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.RenderingHints;
import java.awt.*;
import java.awt.image.*;
import java.io.*;
import javax.imageio.*;
import javax.swing.*;

public class HangmanUIPanel extends JPanel{
    private BufferedImage pic = null;
    
    
    public HangmanUIPanel(){
        setBorder(BorderFactory.createLineBorder(Color.black));
    }
    
    public Dimension getPreferredSize(){
        return new Dimension(600, 400);
    }
    
    public void paintComponent(Graphics g){
        super.paintComponent(g);
        
        try{
            pic = ImageIO.read(new File("src//placeholder.png"));
        }catch(IOException e){}
        g.drawImage(pic, 50, 50, 300, 300, this);
    }
}

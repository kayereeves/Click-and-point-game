package theguild.hangman;

import java.awt.CardLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Container;
import java.awt.event.ActionEvent;
import java.awt.event.WindowAdapter;
import javax.swing.AbstractAction;
import javax.swing.Action;
import javax.swing.ImageIcon;
import javax.swing.JComponent;
import static javax.swing.JComponent.WHEN_IN_FOCUSED_WINDOW;
import javax.swing.KeyStroke;
import javax.swing.WindowConstants;


public class ControlWindow extends javax.swing.JFrame {

    final static String STARTSCREEN = "StartScreen";
    final static String MENUSCREEN = "MenuScreen";
    final static String CREDITS = "Credits";
    final static String HIGHSCORES = "HighScores";
    final static String HSENTRY = "HSEntry";
    final static String ENDSCREEN = "EndScreen";
    final static String HANGMANGAME = "HangmanGame";
    final static String COLORGAME = "ColorGame";
    final static String SUDOKUGAME = "SudokuGame";
    final static String SWINGPONG = "SwingPong";
    final static String PONGENDSCREEN = "PongEndScreen";
    final static String GAMEINFO = "GameInfo";
    public static ImageIcon img = new javax.swing.ImageIcon("src//main//java//resources//tgicon.png");
    boolean gameInfoToggle = true;
    Container gameInfoPane;
    
public ControlWindow() {
        this(STARTSCREEN);
    }
    
    public ControlWindow(String screen) {
        initComponents();
        gameInfoPane = new GameInfo().getContentPane();
        this.setIconImage(img.getImage());
        changeScreen(screen, 0, 0, 0);
        addInfoKeyListener();
        addEscKeyListener(); 
        this.pack();
        this.setDefaultCloseOperation(EXIT_ON_CLOSE);
        int score = 0; int score2 = 0; int place = 0;
    }

    public void changeScreen(String screen, int score, int place, int score2) {
        screenViewer.removeAll();
        CardLayout cards = (CardLayout)(screenViewer.getLayout());
        
        switch (screen) {
        case STARTSCREEN:         
            screenViewer.add(new StartScreen(this).getContentPane(), STARTSCREEN);
            cards.show(screenViewer, STARTSCREEN);
            break;
        case MENUSCREEN:
            screenViewer.add(new MenuScreen(this).getContentPane(), MENUSCREEN);
            cards.show(screenViewer, MENUSCREEN);
            break;
        case CREDITS:
            screenViewer.add(new Credits(this).getContentPane(), CREDITS);
            cards.show(screenViewer, CREDITS);
            break;
        case HIGHSCORES:
            screenViewer.add(new HighScores(this).getContentPane(), HIGHSCORES);
            cards.show(screenViewer, HIGHSCORES);
            break;
        case HSENTRY:
            screenViewer.add(new HSEntry(this, score, place).getContentPane(), HSENTRY);
            cards.show(screenViewer, HSENTRY);
            break;
        case ENDSCREEN:
            screenViewer.add(new EndScreen(this, score).getContentPane(), ENDSCREEN);
            cards.show(screenViewer, ENDSCREEN);
            break;
        case HANGMANGAME:
            screenViewer.add(new HangmanGame(this).getContentPane(), HANGMANGAME);
            cards.show(screenViewer, HANGMANGAME);
            break;
        case COLORGAME:
            screenViewer.add(new ColorGame(this, score).getContentPane(), COLORGAME);
            cards.show(screenViewer, COLORGAME);
            break;
        case SUDOKUGAME:
            screenViewer.add(new SudokuGame(this, score).getContentPane(), SUDOKUGAME);
            cards.show(screenViewer, SUDOKUGAME);
            break;
        case SWINGPONG:
            screenViewer.add(new SwingPong(this).getContentPane(), SWINGPONG);
             cards.show(screenViewer, SWINGPONG);
            break;
        case PONGENDSCREEN:
            screenViewer.add(new PongEndScreen(this, score, score2).getContentPane(), PONGENDSCREEN);
            cards.show(screenViewer, PONGENDSCREEN);
            break;
        case GAMEINFO:
            changeScreen(MENUSCREEN);
            screenViewer.add(gameInfoPane, GAMEINFO);
            toggleGameInfo();
            break;
           // gameInfoToggle = false;
        }
        
        this.pack();
        this.repaint();
        this.revalidate();
       
    }
    
    public void changeScreen (String screen, int score) {
        changeScreen(screen, score, 0, 0);
    }
    
    public void changeScreen (String screen, int score, int score2) {
        changeScreen(screen, score, 0, score2);
    }
    
    public void changeScreen (String screen) {
        changeScreen(screen, 0, 0, 0);
    }
    
    public void toggleGameInfo() {
        CardLayout cards = (CardLayout)(screenViewer.getLayout());

        if (gameInfoToggle) {
            screenViewer.remove(gameInfoPane);
            screenViewer.add(gameInfoPane, GAMEINFO);
              
        }
        cards.next(screenViewer);  
        
        gameInfoToggle = !gameInfoToggle;
            
        this.pack();
    }
    
    private void addInfoKeyListener() {
        Action toggleInfoAction = new AbstractAction() {
            public void actionPerformed(ActionEvent e) {
                toggleGameInfo();
            }
        };
        
        screenViewer.getInputMap(WHEN_IN_FOCUSED_WINDOW).put(KeyStroke.getKeyStroke("F1"),
                "toggleGameInfo");
        screenViewer.getActionMap().put("toggleGameInfo", toggleInfoAction);
    }
    
    private void addEscKeyListener() {
        screenViewer.getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW).put(
            KeyStroke.getKeyStroke("ESCAPE"), "closing the dialog");
        screenViewer.getActionMap().put("closing the dialog", new AbstractAction(){
            public void actionPerformed(ActionEvent e)
            {
                closeWindow();
            }
        });
    }
    
    private void closeWindow() {
        
        System.exit(0);
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        screenViewer = new javax.swing.JPanel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        screenViewer.setLayout(new java.awt.CardLayout());
        getContentPane().add(screenViewer, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 600, 400));

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(ControlWindow.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(ControlWindow.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(ControlWindow.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(ControlWindow.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new ControlWindow().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel screenViewer;
    // End of variables declaration//GEN-END:variables
}


package theguild.hangman;

import java.awt.Color;
import static java.lang.Thread.sleep;
import java.text.DateFormat;
import java.util.Calendar;

/**
 *
 * @author kiann
 */
public class ColorGame extends javax.swing.JFrame {
    
    private static Color bgColor = java.awt.Color.blue.darker().darker().darker().darker();
    private static int currentScore = 0;
    private static int turns = 0;
    private static String lbColorName;
    private static String lbTextString;
    private static String colorChoice;
    private static String[] colorList = {"red", "blue", "green", "yellow", "purple"};
    private static int numColors = colorList.length;

    public ColorGame(int score) {
        turns = 0;
        initComponents();
        resetTextAndColor();
        currentScore = score;
        getContentPane().setBackground(bgColor);
        colorText.setBackground(bgColor);
        javax.swing.ImageIcon img = new javax.swing.ImageIcon("src//main//java//resources//hangmanicon.png");
        setIconImage(img.getImage());
        clock();
    }
    
    public ColorGame() {
        turns = 0;
        initComponents();
        resetTextAndColor();
        getContentPane().setBackground(bgColor);
        colorText.setBackground(bgColor);
        javax.swing.ImageIcon img = new javax.swing.ImageIcon("src//main//java//resources//hangmanicon.png");
        setIconImage(img.getImage());
        clock();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        colorText = new javax.swing.JLabel();
        redButton = new javax.swing.JButton();
        blueButton = new javax.swing.JButton();
        greenButton = new javax.swing.JButton();
        yellowButton = new javax.swing.JButton();
        purpleButton = new javax.swing.JButton();
        lbClock = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        colorText.setFont(new java.awt.Font("Showcard Gothic", 0, 48)); // NOI18N
        colorText.setForeground(new java.awt.Color(0, 153, 153));
        colorText.setText("Color");

        redButton.setBackground(java.awt.Color.red);
        redButton.setText("red");
        redButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                redButtonActionPerformed(evt);
            }
        });

        blueButton.setBackground(java.awt.Color.blue);
        blueButton.setText("blue");
        blueButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                blueButtonActionPerformed(evt);
            }
        });

        greenButton.setBackground(java.awt.Color.green);
        greenButton.setText("green");
        greenButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                greenButtonActionPerformed(evt);
            }
        });

        yellowButton.setBackground(java.awt.Color.yellow);
        yellowButton.setText("yellow");
        yellowButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                yellowButtonActionPerformed(evt);
            }
        });

        purpleButton.setBackground(java.awt.Color.magenta);
        purpleButton.setText("purple");
        purpleButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                purpleButtonActionPerformed(evt);
            }
        });

        lbClock.setFont(new java.awt.Font("Showcard Gothic", 0, 10)); // NOI18N
        lbClock.setForeground(new java.awt.Color(0, 153, 153));
        lbClock.setText("clock");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(170, 170, 170)
                        .addComponent(yellowButton, javax.swing.GroupLayout.PREFERRED_SIZE, 82, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(92, 92, 92)
                        .addComponent(greenButton, javax.swing.GroupLayout.PREFERRED_SIZE, 82, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(lbClock, javax.swing.GroupLayout.PREFERRED_SIZE, 168, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(81, 81, 81)
                        .addComponent(blueButton, javax.swing.GroupLayout.PREFERRED_SIZE, 82, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(91, 91, 91)
                        .addComponent(purpleButton, javax.swing.GroupLayout.PREFERRED_SIZE, 82, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 97, Short.MAX_VALUE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(175, 175, 175)
                        .addComponent(colorText, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)))
                .addComponent(redButton, javax.swing.GroupLayout.PREFERRED_SIZE, 82, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(85, 85, 85))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lbClock, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(2, 2, 2)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(180, 180, 180)
                        .addComponent(blueButton, javax.swing.GroupLayout.PREFERRED_SIZE, 77, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(greenButton, javax.swing.GroupLayout.PREFERRED_SIZE, 77, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(yellowButton, javax.swing.GroupLayout.PREFERRED_SIZE, 77, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(28, 28, 28)
                                .addComponent(colorText, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(32, 32, 32)
                                .addComponent(purpleButton, javax.swing.GroupLayout.PREFERRED_SIZE, 77, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(redButton, javax.swing.GroupLayout.PREFERRED_SIZE, 77, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(41, 41, 41)))))
                .addGap(44, 70, Short.MAX_VALUE))
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void yellowButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_yellowButtonActionPerformed
        colorChoice = "yellow";
        compareColors();
    }//GEN-LAST:event_yellowButtonActionPerformed

    private void greenButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_greenButtonActionPerformed
        colorChoice = "green";
        compareColors();
    }//GEN-LAST:event_greenButtonActionPerformed

    private void blueButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_blueButtonActionPerformed
        colorChoice = "blue";
        compareColors();
    }//GEN-LAST:event_blueButtonActionPerformed

    private void purpleButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_purpleButtonActionPerformed
        colorChoice = "purple";
        compareColors();
    }//GEN-LAST:event_purpleButtonActionPerformed

    private void redButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_redButtonActionPerformed
        colorChoice = "red";
        compareColors();
    }//GEN-LAST:event_redButtonActionPerformed

    private void clock()
    {
        Thread clock = new Thread()
        {
            public void run()
            {
                try{
                    for(;;){
                        Calendar calendar = 
                        new java.util.GregorianCalendar(Calendar.getInstance()
                                                                .getTimeZone());
                        DateFormat df = 
                        new java.text.SimpleDateFormat("MMMMM dd, YYYY "
                                                       + "hh:mm:ss");
                        String date = df.format(calendar.getTime());
       
                        lbClock.setText(date);
                        sleep(1000);
                    }
                }catch (InterruptedException e)
                {
                    e.printStackTrace();
                }
            }
        };
        
        clock.start();     
    }
    
    private String pickColor(String[] colors) {
        int index = (int) (Math.random() * colors.length);
        String randomColor = new String(colors[index]);
        
        return randomColor;
    }
    
    private void setColorTextState(String color, String text) {
        colorText.setText(text);
        lbTextString = text;
        lbColorName = color;
        
        switch (color) {
            case "red":
                colorText.setForeground(java.awt.Color.RED);
                break;
            
            case "blue":
                colorText.setForeground(java.awt.Color.BLUE);
                break;
            
            case "green":
                colorText.setForeground(java.awt.Color.GREEN);
                break;
                
            case "yellow":
                colorText.setForeground(java.awt.Color.YELLOW);
                break;
                
            case "purple":
                colorText.setForeground(java.awt.Color.MAGENTA);
                break;
                
            default:
                System.out.println("Invalid color");
                break;
        }     
    }
    
    private void resetTextAndColor()
    {
        setColorTextState(pickColor(colorList), pickColor(colorList));
    }
            
    private void compareColors() {   
        turns++;
        
        if (colorChoice.equals(lbColorName))
        {
            currentScore += 100;
        }
        
        if (turns >= 5) {
            EndScreen end = new EndScreen(currentScore);
            end.setSize(600, 400);
            end.setVisible(true);
            this.setVisible(false);
            this.setDefaultCloseOperation(this.EXIT_ON_CLOSE);
            this.dispose();
        }
        else {
            resetTextAndColor();
        }        
    }
    
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(ColorGame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(ColorGame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(ColorGame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(ColorGame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new ColorGame().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton blueButton;
    private javax.swing.JLabel colorText;
    private javax.swing.JButton greenButton;
    private javax.swing.JLabel lbClock;
    private javax.swing.JButton purpleButton;
    private javax.swing.JButton redButton;
    private javax.swing.JButton yellowButton;
    // End of variables declaration//GEN-END:variables
}

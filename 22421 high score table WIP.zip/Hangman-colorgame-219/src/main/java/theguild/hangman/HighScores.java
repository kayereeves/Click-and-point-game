
package theguild.hangman;

import java.awt.Color;
import java.util.Scanner;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

/**
 *
 * @author kiann
 */
public class HighScores extends javax.swing.JFrame {
    
    private String init1;
    private String init2;
    private String init3;
    private String score1;
    private String score2;
    private String score3;

    public HighScores() {
        setPreferredSize(GlobalCode.dims);
        pack();
        initComponents();
        retrieveScores();
        getContentPane().setBackground(GlobalCode.bgColor);
        setIconImage(GlobalCode.img.getImage());
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        highScoresText = new javax.swing.JLabel();
        hsBackButton = new javax.swing.JButton();
        score1Text = new javax.swing.JLabel();
        score2Text = new javax.swing.JLabel();
        score3Text = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        highScoresText.setFont(new java.awt.Font("Showcard Gothic", 0, 36)); // NOI18N
        highScoresText.setForeground(new java.awt.Color(0, 153, 153));
        highScoresText.setText("High Scores");

        hsBackButton.setBackground(new java.awt.Color(0, 51, 51));
        hsBackButton.setFont(new java.awt.Font("Showcard Gothic", 0, 10)); // NOI18N
        hsBackButton.setForeground(new java.awt.Color(0, 153, 153));
        hsBackButton.setText("Back to menu");
        hsBackButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                hsBackButtonActionPerformed(evt);
            }
        });

        score1Text.setFont(new java.awt.Font("Showcard Gothic", 0, 24)); // NOI18N
        score1Text.setForeground(new java.awt.Color(0, 153, 153));
        score1Text.setText("ABC.....00000");

        score2Text.setFont(new java.awt.Font("Showcard Gothic", 0, 24)); // NOI18N
        score2Text.setForeground(new java.awt.Color(0, 153, 153));
        score2Text.setText("ABC.....00000");

        score3Text.setFont(new java.awt.Font("Showcard Gothic", 0, 24)); // NOI18N
        score3Text.setForeground(new java.awt.Color(0, 153, 153));
        score3Text.setText("ABC.....00000");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(217, 217, 217)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(score2Text)
                            .addComponent(score1Text, javax.swing.GroupLayout.PREFERRED_SIZE, 159, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(score3Text)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(8, 8, 8)
                                .addComponent(hsBackButton, javax.swing.GroupLayout.PREFERRED_SIZE, 133, javax.swing.GroupLayout.PREFERRED_SIZE))))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(173, 173, 173)
                        .addComponent(highScoresText)))
                .addContainerGap(197, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(63, 63, 63)
                .addComponent(highScoresText)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(score1Text, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(score2Text)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(score3Text)
                .addGap(28, 28, 28)
                .addComponent(hsBackButton, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(111, Short.MAX_VALUE))
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void hsBackButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_hsBackButtonActionPerformed
        HangmanUI menu = new HangmanUI();
        menu.setSize(600,400);
        menu.setVisible(true);
        this.setVisible(false);
        this.setDefaultCloseOperation(this.EXIT_ON_CLOSE);
        this.dispose();
    }//GEN-LAST:event_hsBackButtonActionPerformed

    private void hsMainMenuButtonActionPerformed(java.awt.event.ActionEvent evt) {                                         
        HangmanUI menu = new HangmanUI();
        menu.setSize(600,400);
        menu.setVisible(true);
        this.setVisible(false);
        this.setDefaultCloseOperation(this.EXIT_ON_CLOSE);
        this.dispose();
    } 
    
    //gets the high score info from a highscoretable.txt file
    private void retrieveScores() {
        try {
            Scanner hsread = new Scanner(new File("src//main//java//resources//highscoretable.txt"));
            hsread.useDelimiter(":");    
            String initials;
            String score;
            
            init1 = hsread.next();
            score1 = hsread.next();
            score1Text.setText(init1 + "....." + score1);
            
            init2 = hsread.next();
            score2 = hsread.next();
            score2Text.setText(init2 + "....." + score2);
            
            init3 = hsread.next();
            score3 = hsread.next();
            score3Text.setText(init3 + "....." + score3);
            hsread.close();
        }
        catch (FileNotFoundException e) {
            System.err.println("Error: invalid HST file");
        }   
    }
    
    public void setScore(int score, int position)
    {
        switch(position) {
            case 1:
                score1 = String.format("%05d", score);
                break;
            
            case 2:
                score2 = String.format("%05d", score);
                break;
                
            case 3:
                score3 = String.format("%05d", score);
                break;
                
            default:
                System.err.println("Error: failed to write score");
                break;
        }
    }
    
    public void setInit(String initials, int position)
    {
        switch(position) {
            case 1:
                init1 = initials;
                break;
            
            case 2:
                init2 = initials;
                break;
                
            case 3:
                init3 = initials;
                break;
                
            default:
                System.err.println("Error: failed to write initials");
                break;
        }
    }
    
    public String getScore(int position)
    {
        switch(position) {
            case 1:
                return score1;
            
            case 2:
                return score2;
            
            case 3:
                return score3;
            
            default:
                System.err.println("Error: invalid score");
                return null;
        }
    }
    
    public String getInit(int position)
    {
        switch(position) {
            case 1:
                return init1;
            
            case 2:
                return init2;
            
            case 3:
                return init3;
            
            default:
                System.err.println("Error: invalid initial");
                return null;
        }
    }
    
    public int getScoreIntValue(int position)
    {
        switch(position) {
            case 1:
                return Integer.valueOf(score1);

            case 2:
                return Integer.valueOf(score2);
                
            case 3:
                return Integer.valueOf(score3);
            
            default:
                System.err.println("Error: invalid score position");
                return 0;
        }
    }  
    
    public void updateScoreFile()
    {
        try {
            FileWriter hsWrite = new FileWriter(new File("src//main//java//resources//highscoretable.txt"));
            PrintWriter hsPrint = new PrintWriter(hsWrite);
            hsPrint.printf(init1 + ':');
            hsPrint.printf(score1);
            hsPrint.printf(init2 + ':');
            hsPrint.printf(score2);
            hsPrint.printf(init3 + ':');
            hsPrint.printf(score3);
        }
        catch (IOException e) {
            System.err.println("Error: failed to write");
        }
    }
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(HighScores.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(HighScores.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(HighScores.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(HighScores.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new HighScores().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel highScoresText;
    private javax.swing.JButton hsBackButton;
    private javax.swing.JLabel score1Text;
    private javax.swing.JLabel score2Text;
    private javax.swing.JLabel score3Text;
    // End of variables declaration//GEN-END:variables
}

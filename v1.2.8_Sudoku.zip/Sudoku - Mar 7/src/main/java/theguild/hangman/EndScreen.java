
package theguild.hangman;

import java.awt.Color;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

/**
 *
 * @author kiann
 */
public class EndScreen extends javax.swing.JFrame {
    
    public EndScreen(int score) {
        GlobalCode.loadJFramePreferences(this);
        initComponents();
        scoreText.setText(scoreText.getText() + score + " points");
        getContentPane().setBackground(GlobalCode.bgColor);
        endButtonPanel.setBackground(GlobalCode.bgColor);
        setIconImage(GlobalCode.img.getImage());
        int inHST = compareScores(score);
        
        if (inHST > 0 && inHST < 4)
        {
            goToHSEntry(score, inHST);
            this.setVisible(false);
            this.setDefaultCloseOperation(this.EXIT_ON_CLOSE);
            this.dispose();
        }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        endText = new javax.swing.JLabel();
        scoreText = new javax.swing.JLabel();
        endButtonPanel = new javax.swing.JPanel();
        endMenuButton = new javax.swing.JButton();
        endRestartButton = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        endText.setBackground(new java.awt.Color(0, 51, 51));
        endText.setFont(new java.awt.Font("Showcard Gothic", 0, 24)); // NOI18N
        endText.setForeground(new java.awt.Color(0, 153, 153));
        endText.setText("You finished the game!");

        scoreText.setFont(new java.awt.Font("Showcard Gothic", 0, 18)); // NOI18N
        scoreText.setForeground(new java.awt.Color(0, 153, 153));
        scoreText.setText("You scored: ");

        endMenuButton.setBackground(new java.awt.Color(0, 51, 51));
        endMenuButton.setFont(new java.awt.Font("Showcard Gothic", 0, 10)); // NOI18N
        endMenuButton.setForeground(new java.awt.Color(0, 153, 153));
        endMenuButton.setText("Back To Menu");
        endMenuButton.setToolTipText("Go back to the main menu.");
        endMenuButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                endMenuButtonActionPerformed(evt);
            }
        });

        endRestartButton.setBackground(new java.awt.Color(0, 51, 51));
        endRestartButton.setFont(new java.awt.Font("Showcard Gothic", 0, 10)); // NOI18N
        endRestartButton.setForeground(new java.awt.Color(0, 153, 153));
        endRestartButton.setText("Try Again?");
        endRestartButton.setToolTipText("Restart the game.");
        endRestartButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                endRestartButtonActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout endButtonPanelLayout = new javax.swing.GroupLayout(endButtonPanel);
        endButtonPanel.setLayout(endButtonPanelLayout);
        endButtonPanelLayout.setHorizontalGroup(
            endButtonPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(endRestartButton, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(endMenuButton, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 253, Short.MAX_VALUE)
        );
        endButtonPanelLayout.setVerticalGroup(
            endButtonPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, endButtonPanelLayout.createSequentialGroup()
                .addGap(6, 6, 6)
                .addComponent(endRestartButton, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(endMenuButton, javax.swing.GroupLayout.DEFAULT_SIZE, 42, Short.MAX_VALUE)
                .addContainerGap())
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(121, 121, 121)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(10, 10, 10)
                                .addComponent(scoreText, javax.swing.GroupLayout.PREFERRED_SIZE, 254, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(endText, javax.swing.GroupLayout.PREFERRED_SIZE, 309, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(141, 141, 141)
                        .addComponent(endButtonPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(170, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(60, 60, 60)
                .addComponent(endText, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(scoreText, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 80, Short.MAX_VALUE)
                .addComponent(endButtonPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(56, 56, 56))
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void endMenuButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_endMenuButtonActionPerformed
        MenuScreen menu = new MenuScreen();
        menu.setSize(600,400);
        menu.setVisible(true);
        this.setVisible(false);
        this.setDefaultCloseOperation(this.EXIT_ON_CLOSE);
        this.dispose();
    }//GEN-LAST:event_endMenuButtonActionPerformed

    private void endRestartButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_endRestartButtonActionPerformed
        HangmanGame game = new HangmanGame();
        game.setSize(600,400);
        game.setVisible(true);
        this.setVisible(false);
        this.setDefaultCloseOperation(this.EXIT_ON_CLOSE);
        this.dispose();
    }//GEN-LAST:event_endRestartButtonActionPerformed

    //returns 1, 2, or 3 if user's score qualifies for the HST, or 0 if not
    private int compareScores(int score)
    {
        HighScores hst = new HighScores();
        int scorePlace = 0;
        
        for (int i = 3; i >= 1; i--) {
            int highScore = hst.getScoreIntValue(i);
            if (score > highScore) {
                scorePlace = i;
            } 
        }
        
        hst.dispose();
        return scorePlace;
    } 
    
    private void goToHSEntry(int score, int place)
    {
        HSEntry hse = new HSEntry(score, place);
        hse.setAlwaysOnTop( true );
        hse.setVisible(true);
        hse.setSize(new java.awt.Dimension(600, 400));
        setVisible(false);
        setDefaultCloseOperation(this.EXIT_ON_CLOSE);
        dispose();
    }
    
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(EndScreen.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(EndScreen.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(EndScreen.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(EndScreen.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new EndScreen(0).setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel endButtonPanel;
    private javax.swing.JButton endMenuButton;
    private javax.swing.JButton endRestartButton;
    private javax.swing.JLabel endText;
    private javax.swing.JLabel scoreText;
    // End of variables declaration//GEN-END:variables
}

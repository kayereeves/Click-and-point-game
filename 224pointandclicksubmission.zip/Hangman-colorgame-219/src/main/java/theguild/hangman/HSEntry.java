
package theguild.hangman;

import java.awt.Color;
import java.io.File;
import java.io.FileWriter;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Scanner;

/**
 *
 * @author kiann
 */
public class HSEntry extends javax.swing.JFrame {
    
    private int hsPlace;
    private int userScore;
    private String userInit;

    public HSEntry(int score, int place) {
        GlobalCode.loadJFramePreferences(this);
        initComponents();
        getContentPane().setBackground(GlobalCode.bgColor);
        winButtonPanel.setBackground(GlobalCode.bgColor);
        winText.setBackground(GlobalCode.bgColor);
        initText.setBackground(GlobalCode.bgColor);
        hsPlace = place;
        userScore = score;
        setIconImage(GlobalCode.img.getImage());
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        winText = new javax.swing.JLabel();
        winButtonPanel = new javax.swing.JPanel();
        enterInitialsButton = new javax.swing.JButton();
        initText = new javax.swing.JLabel();
        initField = new javax.swing.JTextField();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        winText.setFont(new java.awt.Font("Showcard Gothic", 0, 24)); // NOI18N
        winText.setForeground(new java.awt.Color(0, 153, 153));
        winText.setText("You qualified for the high score table!");

        enterInitialsButton.setBackground(new java.awt.Color(0, 51, 51));
        enterInitialsButton.setFont(new java.awt.Font("Showcard Gothic", 0, 10)); // NOI18N
        enterInitialsButton.setForeground(new java.awt.Color(0, 153, 153));
        enterInitialsButton.setText("OK");
        enterInitialsButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                enterInitialsButtonActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout winButtonPanelLayout = new javax.swing.GroupLayout(winButtonPanel);
        winButtonPanel.setLayout(winButtonPanelLayout);
        winButtonPanelLayout.setHorizontalGroup(
            winButtonPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, winButtonPanelLayout.createSequentialGroup()
                .addGap(38, 38, 38)
                .addComponent(enterInitialsButton, javax.swing.GroupLayout.DEFAULT_SIZE, 259, Short.MAX_VALUE)
                .addContainerGap())
        );
        winButtonPanelLayout.setVerticalGroup(
            winButtonPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, winButtonPanelLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(enterInitialsButton, javax.swing.GroupLayout.PREFERRED_SIZE, 46, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(30, 30, 30))
        );

        initText.setFont(new java.awt.Font("Showcard Gothic", 0, 18)); // NOI18N
        initText.setForeground(new java.awt.Color(0, 153, 153));
        initText.setText("Enter Initials:");

        initField.setFont(new java.awt.Font("Showcard Gothic", 0, 24)); // NOI18N
        initField.setForeground(new java.awt.Color(0, 153, 153));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(0, 32, Short.MAX_VALUE)
                .addComponent(winText, javax.swing.GroupLayout.PREFERRED_SIZE, 548, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(20, 20, 20))
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(150, 150, 150)
                        .addComponent(initText)
                        .addGap(18, 18, 18)
                        .addComponent(initField, javax.swing.GroupLayout.PREFERRED_SIZE, 103, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(119, 119, 119)
                        .addComponent(winButtonPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap(43, Short.MAX_VALUE)
                .addComponent(winText, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(initText, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(initField))
                .addGap(107, 107, 107)
                .addComponent(winButtonPanel, javax.swing.GroupLayout.PREFERRED_SIZE, 59, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(55, 55, 55))
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void enterInitialsButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_enterInitialsButtonActionPerformed
        userInit = initField.getText();
        try {
            updateHST(userInit, userScore, hsPlace);
        }
        catch (IOException e) {
            System.err.println("file not found");
        }
        
        this.setVisible(false);
        this.setDefaultCloseOperation(this.EXIT_ON_CLOSE);
        this.dispose();
    }//GEN-LAST:event_enterInitialsButtonActionPerformed

    //overwrites the HST file to add score
    private void updateHST(String initials, int score, int place) throws IOException
    {
        try {
            HighScores hst = new HighScores();
            hst.setScore(score, place);
            hst.setInit(initials, place);
            hst.updateScoreFile();
            hst.dispose();
        }
        catch (IOException e) {
            System.err.println("file not found");
        }

    }
          
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(HSEntry.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(HSEntry.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(HSEntry.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(HSEntry.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new HSEntry(0,0).setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton enterInitialsButton;
    private javax.swing.JTextField initField;
    private javax.swing.JLabel initText;
    private javax.swing.JPanel winButtonPanel;
    private javax.swing.JLabel winText;
    // End of variables declaration//GEN-END:variables
}

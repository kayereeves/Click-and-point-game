
package theguild.hangman;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileWriter;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Scanner;
import javax.swing.Timer;
import static theguild.hangman.ControlWindow.*;

/**
 *
 * @author kiann
 */
public class HSEntry extends javax.swing.JFrame {
    
    ControlWindow controlWindow;
    private int hsPlace;
    private int userScore;
    private String userInit;

    public HSEntry(ControlWindow controlWindow, int score, int place) {
        this.controlWindow = controlWindow;
        GlobalCode.loadJFramePreferences(this);
        initComponents();
        getContentPane().setBackground(GlobalCode.bgColor);
        hsPlace = place;
        userScore = score;
        setIconImage(GlobalCode.img.getImage());
    }

    //overwrites the HST file to add score
    private void updateHST(String initials, int score, int place) throws IOException
    {
        try {
            HighScores hst = new HighScores();
            hst.setScore(score, place);
            hst.setInit(initials, place);
            hst.updateScoreFile();
            hst.dispose();
        }
        catch (IOException e) {
            System.err.println("file not found");
        }

    }
    
    private boolean isValidInput()
    {
        userInit = initField.getText();
        char[] chars = userInit.toCharArray();
        
        boolean isOnlyLetters = true;
        boolean isRightLength = true;
        boolean isValid;
        
        for (char c: chars)
        {
            if (!Character.isLetter(c))
            {
                isOnlyLetters = false;
            }
        }
        
        if (userInit.length() != 3)
        {
            isRightLength = false;
        }

        if (isOnlyLetters == false || isRightLength == false)
        {   
            isValid = false;
        }
        else
            isValid = true;
        
        return isValid;
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel2 = new javax.swing.JPanel();
        enterInitialsButton = new javax.swing.JButton();
        winText = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        initText = new javax.swing.JLabel();
        initField = new javax.swing.JTextField();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new java.awt.GridBagLayout());

        jPanel2.setOpaque(false);

        enterInitialsButton.setBackground(new java.awt.Color(0, 51, 51));
        enterInitialsButton.setFont(new java.awt.Font("Showcard Gothic", 0, 10)); // NOI18N
        enterInitialsButton.setForeground(new java.awt.Color(0, 153, 153));
        enterInitialsButton.setText("OK");
        enterInitialsButton.setToolTipText("Submit your score to the High Score Table.");
        enterInitialsButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                enterInitialsButtonActionPerformed(evt);
            }
        });

        winText.setFont(new java.awt.Font("Showcard Gothic", 0, 24)); // NOI18N
        winText.setForeground(new java.awt.Color(0, 153, 153));
        winText.setText("You qualified for the high score table!");

        jPanel1.setOpaque(false);

        initText.setFont(new java.awt.Font("Showcard Gothic", 0, 18)); // NOI18N
        initText.setForeground(new java.awt.Color(0, 153, 153));
        initText.setText("Enter Initials:");

        initField.setFont(new java.awt.Font("Showcard Gothic", 0, 24)); // NOI18N
        initField.setForeground(new java.awt.Color(0, 153, 153));

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(0, 0, 0)
                .addComponent(initText)
                .addGap(18, 18, 18)
                .addComponent(initField, javax.swing.GroupLayout.PREFERRED_SIZE, 103, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(0, 0, 0)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(initText, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(initField)))
        );

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(0, 0, 0)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                    .addComponent(enterInitialsButton, javax.swing.GroupLayout.PREFERRED_SIZE, 233, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(winText))
                .addGap(0, 0, 0))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(52, 52, 52)
                .addComponent(winText, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(27, 27, 27)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 105, Short.MAX_VALUE)
                .addComponent(enterInitialsButton, javax.swing.GroupLayout.PREFERRED_SIZE, 46, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(38, 38, 38))
        );

        getContentPane().add(jPanel2, new java.awt.GridBagConstraints());

        setSize(new java.awt.Dimension(614, 437));
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void enterInitialsButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_enterInitialsButtonActionPerformed
        
        if (isValidInput())
        {
            try {
            updateHST(userInit, userScore, hsPlace);
            }
            catch (IOException e) {
                System.err.println("file not found");
            }

            controlWindow.changeScreen(HIGHSCORES);
        }
        else
        {
            winText.setText("Invalid Input: Please Enter Only Three Letters");
            
            int delay = 2000;
            ActionListener taskPerformer = new ActionListener(){
                public void actionPerformed(ActionEvent evt){
                    winText.setText("");
                }
            };
            Timer timer = new Timer(delay, taskPerformer);
            timer.setRepeats(false);
            timer.start();
        }

    }//GEN-LAST:event_enterInitialsButtonActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(HSEntry.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(HSEntry.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(HSEntry.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(HSEntry.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        
        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                 new HSEntry(null, 0, 1).setVisible(true);
//                ControlWindow window = new ControlWindow();
//                window.setVisible(true);
//                window.changeScreen(HSENTRY);
                
                
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton enterInitialsButton;
    private javax.swing.JTextField initField;
    private javax.swing.JLabel initText;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JLabel winText;
    // End of variables declaration//GEN-END:variables
}

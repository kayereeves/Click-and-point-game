
package theguild.hangman;

import javax.swing.SwingUtilities;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.BorderFactory;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.Timer;
import static theguild.hangman.ControlWindow.*;

/**
 *
 * @author kiann
 */
public class StartScreen extends javax.swing.JFrame {
    ControlWindow controlWindow;
    
    public StartScreen() {
        this(null);
    }
    
    public StartScreen(ControlWindow controlWindow) {
        this.controlWindow = controlWindow;
        initComponents();
        GlobalCode.loadJFramePreferences(this);
        setIconImage(GlobalCode.img.getImage());
        
        loadNextWindow();
        
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel4 = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        titleText1 = new javax.swing.JLabel();
        byTheGuild = new javax.swing.JLabel();
        titleText = new javax.swing.JLabel();

        jLabel4.setText("jLabel4");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(0, 51, 51));
        setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        setForeground(new java.awt.Color(0, 153, 153));
        getContentPane().setLayout(new java.awt.GridBagLayout());

        jPanel1.setBackground(new java.awt.Color(0, 34, 34));
        jPanel1.setForeground(new java.awt.Color(0, 51, 51));
        jPanel1.setOpaque(false);

        titleText1.setBackground(new java.awt.Color(0, 34, 34));
        titleText1.setFont(new java.awt.Font("Showcard Gothic", 0, 48)); // NOI18N
        titleText1.setForeground(new java.awt.Color(0, 153, 153));
        titleText1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        titleText1.setText("Point-And-Click");
        titleText1.setToolTipText("");
        titleText1.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);

        byTheGuild.setBackground(new java.awt.Color(0, 34, 34));
        byTheGuild.setFont(new java.awt.Font("Showcard Gothic", 0, 24)); // NOI18N
        byTheGuild.setForeground(new java.awt.Color(0, 153, 153));
        byTheGuild.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        byTheGuild.setText("by The GUI-LD");
        byTheGuild.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);

        titleText.setBackground(new java.awt.Color(0, 34, 34));
        titleText.setFont(new java.awt.Font("Showcard Gothic", 0, 48)); // NOI18N
        titleText.setForeground(new java.awt.Color(0, 153, 153));
        titleText.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        titleText.setText("Game Suite");
        titleText.setToolTipText("");
        titleText.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(titleText1)
                .addGap(0, 0, 0))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(0, 0, 0)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(titleText)
                    .addComponent(byTheGuild, javax.swing.GroupLayout.PREFERRED_SIZE, 216, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(0, 0, 0))
        );

        jPanel1Layout.linkSize(javax.swing.SwingConstants.HORIZONTAL, new java.awt.Component[] {byTheGuild, titleText, titleText1});

        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(0, 0, 0)
                .addComponent(titleText1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(titleText)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(byTheGuild)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        getContentPane().add(jPanel1, new java.awt.GridBagConstraints());

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void loadNextWindow() {
        int delay = 1000;
        ActionListener taskPerformer = new ActionListener(){
            public void actionPerformed(ActionEvent evt){
                openMainMenu();
            }
        };
        Timer timer = new Timer(delay, taskPerformer);
        timer.setRepeats(false);
        timer.start();
    }
    
    public void openMainMenu(){
        controlWindow.changeScreen(MENUSCREEN);
    }
    
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("DarkMetal".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(StartScreen.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(StartScreen.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(StartScreen.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(StartScreen.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                StartScreen s = new StartScreen();
                s.setSize(600, 400);
                s.getContentPane().setBackground(GlobalCode.bgColor);
                s.setVisible(true);
            }
        });
    }
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel byTheGuild;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JLabel titleText;
    private javax.swing.JLabel titleText1;
    // End of variables declaration//GEN-END:variables
}

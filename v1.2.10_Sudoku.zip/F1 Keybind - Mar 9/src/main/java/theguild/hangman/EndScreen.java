
package theguild.hangman;

import java.awt.Color;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;
import static theguild.hangman.ControlWindow.*;

/**
 *
 * @author kiann
 */
public class EndScreen extends javax.swing.JFrame {
    ControlWindow controlWindow;
    int score;
    int inHST;
            
    public EndScreen() {
        this(null, 0);
    }
    
    public EndScreen(ControlWindow controlWindow, int score) {
        GlobalCode.loadJFramePreferences(this);
        this.score = score;
        initComponents();
        scoreText.setText(scoreText.getText() + score + " points");
        getContentPane().setBackground(GlobalCode.bgColor);
        endButtonPanel.setBackground(GlobalCode.bgColor);
        setIconImage(GlobalCode.img.getImage());
        inHST = compareScores(score);
        this.controlWindow = controlWindow;
        
//        if (inHST > 0 && inHST < 4)
//        {
//            goToHSEntry(score, inHST);
//        }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        endText = new javax.swing.JLabel();
        scoreText = new javax.swing.JLabel();
        endButtonPanel = new javax.swing.JPanel();
        endMenuButton = new javax.swing.JButton();
        endRestartButton = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new java.awt.GridBagLayout());

        jPanel1.setOpaque(false);

        endText.setBackground(new java.awt.Color(0, 51, 51));
        endText.setFont(new java.awt.Font("Showcard Gothic", 0, 24)); // NOI18N
        endText.setForeground(new java.awt.Color(0, 153, 153));
        endText.setText("You finished the game!");

        scoreText.setFont(new java.awt.Font("Showcard Gothic", 0, 18)); // NOI18N
        scoreText.setForeground(new java.awt.Color(0, 153, 153));
        scoreText.setText("You scored: ");

        endButtonPanel.setOpaque(false);
        endButtonPanel.setLayout(new java.awt.GridLayout(2, 1, 0, 25));

        endMenuButton.setBackground(new java.awt.Color(0, 51, 51));
        endMenuButton.setFont(new java.awt.Font("Showcard Gothic", 0, 10)); // NOI18N
        endMenuButton.setForeground(new java.awt.Color(0, 153, 153));
        endMenuButton.setText("Back To Menu");
        endMenuButton.setToolTipText("Go back to the main menu.");
        endMenuButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                endMenuButtonActionPerformed(evt);
            }
        });
        endButtonPanel.add(endMenuButton);

        endRestartButton.setBackground(new java.awt.Color(0, 51, 51));
        endRestartButton.setFont(new java.awt.Font("Showcard Gothic", 0, 10)); // NOI18N
        endRestartButton.setForeground(new java.awt.Color(0, 153, 153));
        endRestartButton.setText("Try Again?");
        endRestartButton.setToolTipText("Restart the game.");
        endRestartButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                endRestartButtonActionPerformed(evt);
            }
        });
        endButtonPanel.add(endRestartButton);

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                    .addComponent(scoreText, javax.swing.GroupLayout.PREFERRED_SIZE, 254, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(endText, javax.swing.GroupLayout.PREFERRED_SIZE, 309, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(endButtonPanel, javax.swing.GroupLayout.PREFERRED_SIZE, 266, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap())
        );

        jPanel1Layout.linkSize(javax.swing.SwingConstants.HORIZONTAL, new java.awt.Component[] {endText, scoreText});

        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(endText, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(scoreText, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 95, Short.MAX_VALUE)
                .addComponent(endButtonPanel, javax.swing.GroupLayout.PREFERRED_SIZE, 116, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        getContentPane().add(jPanel1, new java.awt.GridBagConstraints());

        setSize(new java.awt.Dimension(614, 437));
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void endMenuButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_endMenuButtonActionPerformed
        if (inHST > 0 && inHST < 4)
        {
            controlWindow.changeScreen(HSENTRY, score, inHST);
        } else {
            
        controlWindow.changeScreen(MENUSCREEN);
        }
    }//GEN-LAST:event_endMenuButtonActionPerformed

    private void endRestartButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_endRestartButtonActionPerformed
        controlWindow.changeScreen(HANGMANGAME);
    }//GEN-LAST:event_endRestartButtonActionPerformed

    //returns 1, 2, or 3 if user's score qualifies for the HST, or 0 if not
    private int compareScores(int score)
    {
        HighScores hst = new HighScores();
        int scorePlace = 0;
        
        for (int i = 3; i >= 1; i--) {
            int highScore = hst.getScoreIntValue(i);
            if (score > highScore) {
                scorePlace = i;
            } 
        }
        System.out.println(scorePlace + "scoreplace");
        
        hst.dispose();
        return scorePlace;
    } 
    
//    private void goToHSEntry(int score, int place)
//    {
//        controlWindow.changeScreen(HSENTRY, score, place);
//    }
    
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(EndScreen.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(EndScreen.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(EndScreen.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(EndScreen.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new EndScreen().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel endButtonPanel;
    private javax.swing.JButton endMenuButton;
    private javax.swing.JButton endRestartButton;
    private javax.swing.JLabel endText;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JLabel scoreText;
    // End of variables declaration//GEN-END:variables
}
